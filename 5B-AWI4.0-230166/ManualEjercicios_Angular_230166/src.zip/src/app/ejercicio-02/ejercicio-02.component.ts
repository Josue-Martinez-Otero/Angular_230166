import { Component } from '@angular/core';

@Component({
  selector: 'app-ejercicio-02',
  imports: [],
  templateUrl: './ejercicio-02.component.html',
  styleUrl: './ejercicio-02.component.css'
})
export class Ejercicio02Component {

    city = 'Cuacuila, Huauchinango';

}
