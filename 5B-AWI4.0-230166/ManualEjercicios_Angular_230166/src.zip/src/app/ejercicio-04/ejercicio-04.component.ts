import { Component } from '@angular/core';

@Component({
  selector: 'app-ejercicio-04',
  imports: [],
  templateUrl: './ejercicio-04.component.html',
  styleUrl: './ejercicio-04.component.css'
})
export class Ejercicio04Component {
    isLoggedIn = true;
    isServerRuning = true;
}
