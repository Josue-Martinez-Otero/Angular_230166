import { Component } from '@angular/core';

@Component({
  selector: 'app-ejercicio-01',
  imports: [],
  template: `
  Hello Universe
`,
  styles: `
  :host {
    color: #a144eb;
  }
`,
})
export class Ejercicio01Component {

}
