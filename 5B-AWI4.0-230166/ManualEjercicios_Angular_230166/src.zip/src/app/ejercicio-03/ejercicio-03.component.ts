import { Component } from '@angular/core';

@Component({
  selector: 'app-ejercicio-03',
  imports: [],
  templateUrl: './ejercicio-03.component.html',
  styleUrl: './ejercicio-03.component.css'
})
export class Ejercicio03Component {
    username = 'JOSPBY';
}
